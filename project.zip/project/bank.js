function transact()
{
    var availableBal=Number(document.getElementById("avbal").innerHTML);
    var dropDown=document.getElementById("select").value;
    var description=document.getElementById("des").value;
    var value=Number(document.getElementById("val").value);
    var depVal=Number(document.getElementById("depbal").innerHTML);
    var withVal=Number(document.getElementById("withbal").innerHTML);
    var date=Date();
//    var deposit=document.getElementById("dep").value;
//    var withdraw=document.getElementById("with").value;


    console.log(availableBal)

    if(dropDown=="dep")
    {
        //Deposit operation should come here
        if(value==0)
        {
            alert("value is not currect");
        }
        else if(value<0)
            {
                alert("Negative values are not allowed")
            }
        else{
            availableBal=availableBal+value
            document.getElementById("avbal").innerHTML=availableBal;
            
            depVal=depVal+value
            document.getElementById("depbal").innerHTML=depVal;
//            var depo= date+" "+description+" "+value;
            document.getElementById("sin").innerHTML=date+" "+description+" "+value;
        }
    
    }
    
    else{
        //Withdrawl operation should come here
           if(value==0)
        {
            alert("value is not currect")
        }
        else if(value<0)
            {             
                alert("Negative values are not allowed")
            }
        else{
            
            if(value>availableBal)
                {
                    alert("insufficient balance")
                }
            else if(value>0)
                {
                availableBal=availableBal-value
                document.getElementById("avbal").innerHTML=availableBal;
            
                withVal=withVal+value
                document.getElementById("withbal").innerHTML=withVal;
//                var with= date+" "+description+" "+value;
                    document.getElementById("san").innerHTML=date+" "+description+" "+value;
                }
            
            else{
                alert("try again!!!")
            }
        }
    }

}